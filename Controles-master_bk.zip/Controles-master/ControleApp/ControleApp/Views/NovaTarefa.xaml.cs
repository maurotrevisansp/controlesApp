﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ControleApp.Business;
using ControleApp.Model;
using ControleApp.Util;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ControleApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class NovaTarefa : ContentPage
    {
        private Tarefas tarefa;
        public NovaTarefa(Tarefas t = null)
        {
            InitializeComponent();
            if (t != null)
            {
                tarefa = t;
            }
            TxtHoraFim.Text = DateTime.Now.ToString("HH:mm");
        }

        private List<Usuario> usuarios;
        protected  override async void OnAppearing()
        {
            usuarios = await UsuarioRN.GetUsuarios();
            PckCliente.ItemsSource = await ClienteRN.GetClientes();
            PckPara.ItemsSource = usuarios;
            var tipos = await TarefasRN.GetTipo();
            PckTipo.ItemsSource = tipos;
            PckTipo.SelectedItem = tipos.Where(t => t.TarefaTipo.ToUpper().Contains("AGENDA")).FirstOrDefault();
            List<String> acoes = new List<string>();
            acoes.Add("Incluir");
            acoes.Add("Editar");
            acoes.Add("Baixar");
            acoes.Add("Validar");
            acoes.Add("Recusar");
            acoes.Add("Compartilhar");
            acoes.Add("Ler");
            PckAcao.ItemsSource = acoes;
            PckAcao.SelectedItem = "Incluir";
            if (tarefa != null)
            {
                PckCliente.SelectedItem = ((List<Cliente>) PckCliente.ItemsSource).FirstOrDefault(c => c.Id == tarefa.CLIENTE);
                TxtDataFim.Date = tarefa.DATA_PROGR;
                PckPara.SelectedItem = usuarios.FirstOrDefault(u => u.Usw_cod == tarefa.RESPOSAVEL);
                
                PckTipo.SelectedItem = tipos.FirstOrDefault(t => t.TarefaTipo.Contains("Tarefa"));
                TxtDescricao.IsVisible = true;
                TxtDescricao.Text = tarefa.HISTORICO;
                TxtTexto.IsVisible = false;
                //ScrollEditor.ScrollToAsync(0, 0, false);
            }
        }

        private void Enviar_Clicked(object sender, EventArgs e)
        {
            DisplayAlert("Erro", "Por favor preencha os campos necessários.", "OK");
        }

        private async void Enviar(object sender, EventArgs e)
        {
            try
            {
                StckSucesso.IsVisible = false;
                if (PckPara.SelectedIndex == -1 ||
                    PckTipo.SelectedIndex == -1)
                {
                    DisplayAlert("Erro", "Preencha todos os campos", "Ok");
                    return;
                }
                var t = new Tarefas();
                t.CLIENTE = (PckCliente.SelectedIndex == -1) ? Convert.ToInt32(TxtCliente.Text) : ((Cliente)PckCliente.SelectedItem).Id;
                t.DATA_PROGR = TxtDataFim.Date;
                t.SOLICITANTE = Session.Usuario.Usw_cod;
                t.RESPOSAVEL = ((Usuario)PckPara.SelectedItem).Usw_cod;
                t.HISTORICO = TxtTexto.Text;
                t.Prg_NatProg = ((Tipo)PckTipo.SelectedItem).Id;

                var retorno = await TarefasRN.Cadastrar(t);

                if (String.IsNullOrEmpty(retorno))
                {
                    StckSucesso.IsVisible = true;
                    TxtSucesso.Text = "Cadastro realizado com sucesso.";
                }
            }
            catch (Exception exception)
            {
                
                throw exception;
            }
            
        }

        private void textTap(object sender, EventArgs e)
        {
            TxtTexto.Focus();
            if (TxtTexto.Text == "Descrição")
            {
                TxtTexto.Text = "";
            }
        }

        private void BtnApagar_OnClicked(object sender, EventArgs e)
        {
           
            TxtTexto.Text = "";
            StckSucesso.IsVisible = false;
        }

        private void TxtCliente_OnTextChanged(object sender, TextChangedEventArgs e)
        {
           
        }

        private void TxtCliente_OnUnfocused(object sender, FocusEventArgs e)
        {
            if (TxtCliente.Text.Length == 0)
            {
                TxtCliente.Text = "0";
            }
        }

        private void Eu_Clicked(object sender, EventArgs e)
        {
            PckPara.SelectedItem = usuarios.Where(s => s.Usw_cod == Session.Usuario.Usw_cod).FirstOrDefault();
        }
    }
}